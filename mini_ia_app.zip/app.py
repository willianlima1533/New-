
import gradio as gr

def responder(pergunta):
    return "Você perguntou: " + pergunta

gr.Interface(fn=responder, inputs="text", outputs="text", title="Mini IA no Navegador").launch()
